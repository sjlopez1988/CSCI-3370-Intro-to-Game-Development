﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    public GameObject hazard;
    public GameObject enemy;

    public Vector3 spawnValues;
    public int hazardCount;
    public int enemyCount;

    public float spawnWait;
    public float startWait;
    public float waveWait;

    public GUIText scoreText;
    public GUIText restartText;
    public GUIText gameoverText;
    public GUIText stageText;

    private bool gameOver;
    private bool restart;
    public int score;
    public int stage;

    void Start()
    {
        gameOver = false;
        restart = false;
        restartText.text = "";
        gameoverText.text = "";
        score = 0;
        stage = 1;
        UpdateScore();
        UpdateStage();
        StartCoroutine(SpawnWaves());
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void AddStage(int newStageValue)
    {
        stage += newStageValue;
        UpdateStage();
    }

    void UpdateStage()
    {
        stageText.text = "STAGE: " + stage;
    }

    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(startWait);
        while (true)
        {
            for (int i = 0; i < hazardCount; i++)
            {
                Vector3 spawnPosition = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                Quaternion spawnRotation = Quaternion.identity;
                Instantiate(hazard, spawnPosition, spawnRotation);
                yield return new WaitForSeconds(spawnWait);
            }

            for (int j = 0; j < enemyCount; j++)
            {
                Vector3 spawnPosition = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                Quaternion spawnRotation = Quaternion.identity;
                Instantiate(enemy, spawnPosition, spawnRotation);
                yield return new WaitForSeconds(spawnWait);
            }
            
            yield return new WaitForSeconds(waveWait);

            if (gameOver)
            {
                restartText.text = "CONTINUE? \n PRESS 'R' TO RESTART";
                restart = true;
                break;
            }
        }
    }

    public void AddScore(int newScoreValue)
    {
        score += newScoreValue;
        UpdateScore();
    }

    void UpdateScore()
    {
        scoreText.text = "SCORE: " + score;
    }


    public void GameOver()
    {
        gameoverText.text = "GAME OVER!";
        gameOver = true;
        
    }
}
