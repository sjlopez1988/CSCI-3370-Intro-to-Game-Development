﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Quit_to_Title : MonoBehaviour
{

    public void triggerQuit_to_Title_Behavior(int i)
    {
        switch (i)
        {
            default:

            case (0):
                SceneManager.LoadScene("Title Menu");

                break;
        }
    }
}
