﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour {

    float remainingTime = 100;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        remainingTime -= Time.deltaTime;
	}

    void OnGUI()
    {
        if (remainingTime > 0)
        {
            GUIStyle myStyle = new GUIStyle(GUI.skin.label);
            myStyle.fontSize = 50;
            GUI.Label(new Rect(50, 100, 200, 200), "TIMER: " + (int)remainingTime, myStyle);

        }
        else
        {
            GUIStyle myStyle = new GUIStyle(GUI.skin.label);
            myStyle.fontSize = 50;
            GUI.Label(new Rect(50, 100, 200, 200), "TIME'S UP!", myStyle);

            SceneManager.LoadScene("Title Menu");
        }
    }
}
