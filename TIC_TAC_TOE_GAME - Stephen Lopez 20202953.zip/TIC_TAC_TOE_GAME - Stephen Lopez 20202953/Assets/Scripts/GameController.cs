﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//This is the class for the player for public access.
[System.Serializable]
public class Player 
{
    public Image panel;     //Creating a panel object from the image class.
    public Text text;       //Creating a text object from the text class.
    public Button button;   //Creating a button object from the button class.
}

//Class for the player color.
[System.Serializable]
public class PlayerColor
{
    public Color panelColor;    //Creating an panelColor object from the color class.
    public Color textColor;     //Creating an textColor object from the color class.
}

//Creating a public class called GameController that inherits
//from the MonoBehavior class.
public class GameController : MonoBehaviour
{
    public Text[] buttonList;      //Creating a public buttonList array object from the text class.
    public Text gameOverText;      //Creating a public gameOverText from the text class. 

    public Player playerX;      //Creating a playerX object from the Player class.
    public Player playerO;      //Creating a playerO object from the Player class.

    public PlayerColor activePlayerColor;       //Creating an activePlayerColor from the PlayerColor class.
    public PlayerColor inactivePlayerColor;     //Creating an inactivePlayerColor from the PlayerColor class.

    public GameObject restartButton;    //Creating a restartButton object from the GameObject class.
    public GameObject startInfo;        //Creating a startInfo object from the GameObject class.
    public GameObject gameOverPanel;    //Creating a gameOverPanel object from the GameObject class.

    private string playerSide;      //Declaring a string variable called playerSide
    private int moveCount;          //Declaring a int variable called moveCount


    // This function calls the GameController for reference. 
    void Awake()
    {
        SetGameControllerReferenceOnButtons();  //Reference to the GameController. 
        //playerSide = "X";
        gameOverPanel.SetActive(false); //Winner Message is inactive. 
        moveCount = 0;  //Default move is set to 0.
        restartButton.SetActive(false); //Restart button is set to inactive.
        //SetPlayerColors(playerX, playerO);
    }


    //This function updates the game controller buttons reference. 
    void SetGameControllerReferenceOnButtons()
    {
        for (int i = 0; i < buttonList.Length; i++)
        {
            buttonList[i].GetComponentInParent<GridSpace>().SetGameControllerReference(this);
        }
    }

    //Returns the value of Player Side. 
    public string GetPlayerSide()
    {
        return playerSide;
    }

    //This function updates the moves done by both players. 
    public void EndTurn()
    {
        moveCount++;    //Updates the number of moves for each player. 

        if (buttonList[0].text == playerSide && buttonList[1].text == playerSide && buttonList[2].text == playerSide)   //If player gets 3 across from the top
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[3].text == playerSide && buttonList[4].text == playerSide && buttonList[5].text == playerSide)  //If player gets 3 across from the middle
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[6].text == playerSide && buttonList[7].text == playerSide && buttonList[8].text == playerSide)  //If player gets 3 across from the bottom
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[0].text == playerSide && buttonList[3].text == playerSide && buttonList[6].text == playerSide)  //If player gets 3 vertically from the left
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[1].text == playerSide && buttonList[4].text == playerSide && buttonList[7].text == playerSide)  //If player gets 3 vertically down the middle
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[2].text == playerSide && buttonList[5].text == playerSide && buttonList[8].text == playerSide)  //If player gets 3 vertically from the right
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[0].text == playerSide && buttonList[4].text == playerSide && buttonList[8].text == playerSide)  //If player gets 3 diagnolly
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (buttonList[2].text == playerSide && buttonList[4].text == playerSide && buttonList[6].text == playerSide)  //If player gets 3 diagnolly
        {
            GameOver(playerSide);   //Display the winner of the game. 
        }

        else if (moveCount >= 9)
        {
            GameOver("draw");   //Display Draw Game. 
        }
        else
        {
            ChangeSides(); //Switch sides of the player. 
        }

    }

    //Determines which would be active and starting. 
    void ChangeSides()
    {
        playerSide = (playerSide == "X") ? "O" : "X";

        if (playerSide == "X")
        {
            SetPlayerColors(playerX, playerO);
        }
        else
        {
            SetPlayerColors(playerO, playerX);
        }
    }

    //This function sets the color for the active and inactive players.
    void SetPlayerColors(Player newPlayer, Player oldPlayer)
    {
        newPlayer.panel.color = activePlayerColor.panelColor;   //Set the panel color of the active player.
        newPlayer.text.color = activePlayerColor.textColor;     //Set the text color of the active player. 
        oldPlayer.panel.color = inactivePlayerColor.panelColor;     //Set the panel color of the inactive player. 
        oldPlayer.panel.color = inactivePlayerColor.textColor;      //Set the text color of the inactive player. 
    }

    //This function determines the winner of the game. 
    void GameOver(string winningPlayer)
    {
        SetBoardInteractable(false);

        if (winningPlayer == "draw")    //If both of the players are tied.
        {
            SetGameOverText("IT'S A DRAW!");    //Display It's a DRAW
        }
        else
        {
            SetGameOverText(winningPlayer + " Wins!"); //Else display the winner of game. 
        }

        restartButton.SetActive(true);      //Command for the restart button to restart the game. 

        if (winningPlayer == "draw")        //Displays the DRAW message when both tie. 
        {
            SetGameOverText("IT'S A DRAW!");
            SetPlayerColorsInactive();      //Both player slots are set to inactive colors. 
        }

    }

    //This function sets the Game Over text for the winning player. 
    void SetGameOverText(string value)
    {
        gameOverPanel.SetActive(true);
        gameOverText.text = value;
    }

    //This function restarts the game when the restart button is selected. 
    public void RestartGame()
    {
        //playerSide = "X";
        moveCount = 0;
        gameOverPanel.SetActive(false);
        restartButton.SetActive(false);
        //SetPlayerColors(playerX, playerO);
        SetPlayerButtons(true);
        SetPlayerColorsInactive();
        startInfo.SetActive(true);

        for (int i = 0; i < buttonList.Length; i++)
        {

            buttonList[i].text = "";

        }


    }

    //This functions makes the grid spaces on the board selectable for the players. 
    void SetBoardInteractable(bool toggle)
    {
        for (int i = 0; i < buttonList.Length; i++)
        {
            buttonList[i].GetComponentInParent<Button>().interactable = toggle;

        }
    }

    //This functions determines which of the players is going first.
    public void SetStartingSide(string startingSide)
    {
        playerSide = startingSide;
        
        if (playerSide == "X") //If player X is first, then set the active colors to that player.
        {
            SetPlayerColors(playerX, playerO);  //Function sets the color for the active player X. 
        }
        else //Else set the active colors to the player O.
        {
            SetPlayerColors(playerO, playerX);  //Function sets the color for the active player O.
        }

        StartGame(); //Starts the game. 
    }

   //When the game starts, make the gridSpace interactable (selectable).
   void StartGame()
    {
        SetBoardInteractable(true); //Makes the grid space selectable. 
        SetPlayerButtons(false);    //Makes the player buttons non-interactable.
        startInfo.SetActive(false); //Unselectable UI (player select).
    }

    //This function allows the buttons of Player X and O clickable (selectable).
    void SetPlayerButtons(bool toggle)
    {
        playerX.button.interactable = toggle;   //Selectable Player X button.
        playerO.button.interactable = toggle;   //Selectable Player O button.
    }

    //This function sets the inactive colors for the player. 
    void SetPlayerColorsInactive()
    {
        playerX.panel.color = inactivePlayerColor.panelColor;   //Sets the player x panel to inactive color.
        playerX.text.color = inactivePlayerColor.textColor;     //Sets the player x text to inactive color.
        playerO.panel.color = inactivePlayerColor.panelColor;   //Sets the player o panel to inactive color.
        playerO.text.color = inactivePlayerColor.textColor;     //Sets the player o text to inactive color. 
    }
}