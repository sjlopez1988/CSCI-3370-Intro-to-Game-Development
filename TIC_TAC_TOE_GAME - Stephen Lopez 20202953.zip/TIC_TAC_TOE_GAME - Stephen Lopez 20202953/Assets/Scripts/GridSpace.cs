﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Creating a class for the GridSpace that inherits from the 
//MonoBehaviour class for public access. 
public class GridSpace : MonoBehaviour {

    public Button button;       //creating a public object for the buttons of the game.
    public Text buttonText;     //creating a public object for the text on the buttons. 

    private GameController gameController;      //creating a private object for gameController


    //This function references the GameController class.
    public void SetGameControllerReference(GameController controller)
    {
        gameController = controller;    //assigns value of controller to gameController. 
    }


    //This functions creates interaction with the GridSpace buttons.
    public void SetSpace()
    {
        buttonText.text = gameController.GetPlayerSide();   //Assigns either X or O to the gridSpace.
        button.interactable = false;    //After the button is picked, make the same button non-interactable.
        gameController.EndTurn();   //Ends the turn of the player when the selection made. 
    }
}


